-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: criarapi
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bandas`
--

DROP TABLE IF EXISTS `bandas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bandas` (
  `id` int NOT NULL,
  `nome` varchar(150) DEFAULT NULL,
  `primeiroAlbum` varchar(150) DEFAULT NULL,
  `ultimoAlbum` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bandas`
--

LOCK TABLES `bandas` WRITE;
/*!40000 ALTER TABLE `bandas` DISABLE KEYS */;
INSERT INTO `bandas` VALUES (0,'Red Hot Chili Peppers','Freaky Styley','The Getaway'),(1,'In Her Own Words','Brand New Me','Steady Glow'),(2,'blink 182','Flyswatter','Nine'),(3,'Green Day','39/Smooth','Father of All Motherfuckers'),(4,'Linkin Park','Xero','Hybrid Theory (20th Anniversary Edition)'),(5,'Dance Gavin Dance','Downtown Battle Mountain','Afterburner'),(6,'3 Doors Down','3 Doors Down','Us and the Night'),(7,'Ghost Brigade','Guided by Fire','IV - One With the Storm'),(8,'Bring Me The Horizon','Count Your Blessings','Music to Listen To...'),(9,'Cage The Elephant','Cage The Elephant (Expanded Edition)','Social Cues'),(10,'A Day to Remember','And Their Name Was Treason','Bad Vibrations'),(11,'DIIV','Oshin','Deceiver'),(12,'Fall Out Boy','Fall Out Boys Evening Out with Your Girlfriend','Mania'),(13,'Katatonia','Dance of December Souls','City Burials'),(14,'The Killers','The Killers Demo','Imploding the Mirage'),(15,'Korn','Zabriskie Point','The Nothing'),(16,'Mumford & Sons','Sigh No More','For the Throne: Music Inspired by the HBO Series Game of Thrones'),(17,'Neck Deep','Wishful Thinking','All Distortions Are Intentional'),(18,'The Neighbourhood','I Love You','Chip Chrome & The Mono-Tones'),(19,'Nickelback','Curb','Feed the Machine'),(20,'Panic! at the Disco','A Fever You Cant Sweat Out','Pray for the Wicked'),(21,'Papa Roach','Old Friends from Young Years','Who Do You Trust?'),(22,'Paramore','All We Know Is Falling','After Laughter'),(23,'Polyphia','Muse','New Levels New Devils'),(24,'Thirty Seconds to Mars','30 Seconds to Mars','America'),(25,'We Came as Romans','To Plant a Seed','Cold Like War'),(26,'Asking Alexandria','The Irony of Your Perfection','Like a House on Fire');
/*!40000 ALTER TABLE `bandas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-08 12:33:39
